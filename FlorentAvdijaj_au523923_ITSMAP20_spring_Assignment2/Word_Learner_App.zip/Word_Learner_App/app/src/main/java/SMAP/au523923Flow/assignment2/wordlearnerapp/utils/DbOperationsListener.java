package SMAP.au523923Flow.assignment2.wordlearnerapp.utils;

public interface DbOperationsListener<T> {
    void DbOperationDone(T object);
}
